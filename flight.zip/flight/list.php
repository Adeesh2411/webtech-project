<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./flight-f.css">
	<title></title>
</head>
<body>
	

		<div class="one">
			<img src="./topvoucher-logo (1).png" style="position: absolute;width: 5%;z-index: 1; margin-top: 4cm;left: 2cm;">
			<span style="position: absolute; left: 5cm;color: white ">to</span>
			<span style="position: absolute; left: 12cm;color: white">from</span>

			<span style="position: absolute;left: 21.5cm;color: white">depart</span>
			<span style="position: absolute;left: 27.5cm;color: white">return</span>
			<div class="from">
				<span style="size:2em; position: absolute;margin: 10px;" id="from;">from</span>
			</div>
				<div class="to">
					<span id="to" style="position: absolute;margin:10px;"></span>
				</div>
					<div class="d-date">
						<span id="d-date" style="position: absolute;margin: 10px;">1date</span>
					</div>
						<div class="f-date">
							<span id="f-date" style="position: absolute;margin: 10px;">date</span>
						</div>
		<div class="two">
			<span style="display: inline;float: left;margin-left: 3cm;margin-top: 10px; ">Airlines</span>
			<span style="display: inline;float: left; margin-left: 4cm;margin-top: 10px;">Departure</span>
			<span style="display: inline;float: left; margin-left: 4cm;margin-top: 10px;">Duration</span>
			<span style="display: inline;float: left; margin-left: 4cm;margin-top: 10px;">Arrival</span>
			<span style="display: inline;float: left; margin-left: 4cm;margin-top: 10px;">price</span>
		</div>
		<span style="color: orange;margin-left: 4cm;margin-top:4.5cm;position: absolute;font-weight: bold;font-size: 2em; ">All Flights</span>
		<div class="three" style="margin-top: 6cm;margin-left: 3cm;">
			<img src="./c0e9134cea71190d29f1e0955b678feb.png" style="height: 50%;position: absolute;margin-top: 0.5cm">
			<span style="position: absolute;margin-left: 5.5cm;margin-top: 1cm;font-size: 1.5em;">16:15 php</span>
			<span style="position: absolute;margin-left: 10.5cm;margin-top: 1cm;font-size: 1.5em;">1:05<span style="color: #D7DBDD  ">(non-stop)</span></span>
			<span style="position: absolute;margin-left: 15.5cm;margin-top: 1cm;font-size: 1.5em;">18:15<span style="color: #D7DBDD  ">php</span></span>
			<span style="position: absolute;margin-left: 20.5cm;margin-top: 1cm;font-size: 1.5em;">Rs 3788<span style="color: #D7DBDD  "></span></span>
			<button style="background-color: #DC7633  ;margin-left: 23.5cm;width: 3cm;font-size: 1.5em;position: absolute;color: white;margin-top: 1cm;border-radius: 5px;"></i>book</button>
			<div class="three">
				<img src="./images_1.jpeg" style="height: 50%;position: absolute;margin-top: 0.5cm;margin-left: 0.5cm">
			<span style="position: absolute;margin-left: 5.5cm;margin-top: 1cm;font-size: 1.5em;">16:15 php</span>
			<span style="position: absolute;margin-left: 10.5cm;margin-top: 1cm;font-size: 1.5em;">1:05<span style="color: #D7DBDD  ">(non-stop)</span></span>
			<span style="position: absolute;margin-left: 15.5cm;margin-top: 1cm;font-size: 1.5em;">18:15<span style="color: #D7DBDD  ">php</span></span>
			<span style="position: absolute;margin-left: 20.5cm;margin-top: 1cm;font-size: 1.5em;">Rs 3788<span style="color: #D7DBDD  "></span></span>
			<button style="background-color: #DC7633  ;margin-left: 23.5cm;width: 3cm;font-size: 1.5em;position: absolute;color: white;margin-top: 1cm;border-radius: 5px;">book</button>
				<div class="three">
					<img src="./singapore-airlines-logo.gif" style="height: 50%;position: absolute;">
			<span style="position: absolute;margin-left: 5.5cm;margin-top: 1cm;font-size: 1.5em;">16:15 php</span>
			<span style="position: absolute;margin-left: 10.5cm;margin-top: 1cm;font-size: 1.5em;">1:05<span style="color: #D7DBDD  ">(non-stop)</span></span>
			<span style="position: absolute;margin-left: 15.5cm;margin-top: 1cm;font-size: 1.5em;">18:15<span style="color: #D7DBDD  ">php</span></span>
			<span style="position: absolute;margin-left: 20.5cm;margin-top: 1cm;font-size: 1.5em;">Rs 3788<span style="color: #D7DBDD  "></span></span>
			<button style="background-color: #DC7633  ;margin-left: 23.5cm;width: 3cm;font-size: 1.5em;position: absolute;color: white;margin-top: 1cm;border-radius: 5px;">book</button>
					<div class="three">
						<img src="./Jet_Airways_tcm638-1083202.png" style="height: 70%;position: absolute;">
			<span style="position: absolute;margin-left: 5.5cm;margin-top: 1cm;font-size: 1.5em;">16:15 php</span>
			<span style="position: absolute;margin-left: 10.5cm;margin-top: 1cm;font-size: 1.5em;">1:05<span style="color: #D7DBDD  ">(non-stop)</span></span>
			<span style="position: absolute;margin-left: 15.5cm;margin-top: 1cm;font-size: 1.5em;">18:15<span style="color: #D7DBDD  ">php</span></span>
			<span style="position: absolute;margin-left: 20.5cm;margin-top: 1cm;font-size: 1.5em;">Rs 3788<span style="color: #D7DBDD  "></span></span>
			<button style="background-color: #DC7633  ;margin-left: 23.5cm;width: 3cm;font-size: 1.5em;position: absolute;color: white;margin-top: 1cm;border-radius: 5px;">book</button>
					<div class="three">
						<img src="./Jet_Airways_tcm638-1083202.png" style="height: 70%;position: absolute;">
			<span style="position: absolute;margin-left: 5.5cm;margin-top: 1cm;font-size: 1.5em;">16:15 php</span>
			<span style="position: absolute;margin-left: 10.5cm;margin-top: 1cm;font-size: 1.5em;">1:05<span style="color: #D7DBDD  ">(non-stop)</span></span>
			<span style="position: absolute;margin-left: 15.5cm;margin-top: 1cm;font-size: 1.5em;">18:15<span style="color: #D7DBDD  ">php</span></span>
			<span style="position: absolute;margin-left: 20.5cm;margin-top: 1cm;font-size: 1.5em;">Rs 3788<span style="color: #D7DBDD  "></span></span>
			<button style="background-color: #DC7633  ;margin-left: 23.5cm;width: 3cm;font-size: 1.5em;position: absolute;color: white;margin-top: 1cm;border-radius: 5px;">book</button>
						<div class="three">
						<img src="./Jet_Airways_tcm638-1083202.png" style="height: 70%;position: absolute;">
			<span style="position: absolute;margin-left: 5.5cm;margin-top: 1cm;font-size: 1.5em;">16:15 php</span>
			<span style="position: absolute;margin-left: 10.5cm;margin-top: 1cm;font-size: 1.5em;">1:05<span style="color: #D7DBDD  ">(non-stop)</span></span>
			<span style="position: absolute;margin-left: 15.5cm;margin-top: 1cm;font-size: 1.5em;">18:15<span style="color: #D7DBDD  ">php</span></span>
			<span style="position: absolute;margin-left: 20.5cm;margin-top: 1cm;font-size: 1.5em;">Rs 3788<span style="color: #D7DBDD  "></span></span>
			<button style="background-color: #DC7633  ;margin-left: 23.5cm;width: 3cm;font-size: 1.5em;position: absolute;color: white;margin-top: 1cm;border-radius: 5px;">book</button>
						<div class="three">
						<img src="./Jet_Airways_tcm638-1083202.png" style="height: 70%;position: absolute;">
			<span style="position: absolute;margin-left: 5.5cm;margin-top: 1cm;font-size: 1.5em;">16:15 php</span>
			<span style="position: absolute;margin-left: 10.5cm;margin-top: 1cm;font-size: 1.5em;">1:05<span style="color: #D7DBDD  ">(non-stop)</span></span>
			<span style="position: absolute;margin-left: 15.5cm;margin-top: 1cm;font-size: 1.5em;">18:15<span style="color: #D7DBDD  ">php</span></span>
			<span style="position: absolute;margin-left: 20.5cm;margin-top: 1cm;font-size: 1.5em;">Rs 3788<span style="color: #D7DBDD  "></span></span>
			<button style="background-color: #DC7633  ;margin-left: 23.5cm;width: 3cm;font-size: 1.5em;position: absolute;color: white;margin-top: 1cm;border-radius: 5px;">book</button>
						<div class="three">
						<img src="./Jet_Airways_tcm638-1083202.png" style="height: 70%;position: absolute;">
			<span style="position: absolute;margin-left: 5.5cm;margin-top: 1cm;font-size: 1.5em;">16:15 php</span>
			<span style="position: absolute;margin-left: 10.5cm;margin-top: 1cm;font-size: 1.5em;">1:05<span style="color: #D7DBDD  ">(non-stop)</span></span>
			<span style="position: absolute;margin-left: 15.5cm;margin-top: 1cm;font-size: 1.5em;">18:15<span style="color: #D7DBDD  ">php</span></span>
			<span style="position: absolute;margin-left: 20.5cm;margin-top: 1cm;font-size: 1.5em;">Rs 3788<span style="color: #D7DBDD  "></span></span>
			<button style="background-color: #DC7633  ;margin-left: 23.5cm;width: 3cm;font-size: 1.5em;position: absolute;color: white;margin-top: 1cm;border-radius: 5px;">book</button>
			<div >
			<img src="./traveltrolley.jpg" class="side">
		</div>
		<div>
			<img src="./image_thumb36.png" class="side1">
		</div>
		<div>
			<img src="./transport-2292028_1920.jpg" class="side2">
		</div>
						</div>
						</div>
						</div>

						</div>

					</div>
				</div>
			</div>
			
		</div>
		
	
<fieldset>
	
</fieldset>
	<script type="text/javascript">
	
		var fplace=sessionStorage.getItem('from');
		var to=sessionStorage.getItem('to');
		var fd=sessionStorage.getItem('dep');
		var ret=sessionStorage.getItem('ret');
		var a=document.getElementById('to').innerHTML=fplace;
	
	</script>
</body>
</html>
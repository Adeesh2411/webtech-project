<?php
$fr=$_POST['from'];
$to=$_POST['to'];
$dep=$_POST['deparure'];
$ret=$_POST['return'];

?>

<?php
/*$sql = "CREATE TABLE SAirlines (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
place VARCHAR(30) NOT NULL,
departure INT(6) NOT NULL,
duration INT(6) NOT NULL,
price INT(6) NOT NULL,
reg_date TIMESTAMP
)";
mysqli_query($conn,$sql);
*/
//$a=mysqli_multi_query($conn,$sql1);
?>

<?php
	$conn=mysqli_connect('localhost','root','',"$fr");
	//spice_jet
	$sql="SELECT departure,duration,price FROM data1 WHERE place='$to'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)>0)
	{
		while($row=mysqli_fetch_assoc($result))
		{
//			echo "Adeesh";
			$s_dep=$row['departure'];
			$s_dur=$row['duration'];
			$s_prc=$row['price'];
		}
	}
	//jet airlines
	$sql="SELECT departure,duration,price FROM jet WHERE place='$to'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)>0)
	{
		while($row=mysqli_fetch_assoc($result))
		{
			$j_dep=$row['departure'];
			$j_dur=$row['duration'];
			$j_prc=$row['price'];
		}
	}
	//Singapore airlines
	$sql="SELECT departure,duration,price FROM SAirlines WHERE place='$to'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)>0)
	{
		while($row=mysqli_fetch_assoc($result))
		{
			$sg_dep=$row['departure'];
			$sg_dur=$row['duration'];
			$sg_prc=$row['price'];
		}
	}
	//UIA
	$sql="SELECT departure,duration,price FROM UIA WHERE place='$to'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)>0)
	{
		while($row=mysqli_fetch_assoc($result))
		{
			$u_dep=$row['departure'];
			$u_dur=$row['duration'];
			$u_prc=$row['price'];
		}
	}

?>



<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<script type="text/javascript">
		sessionStorage.setItem('from','<?php echo $fr ?>');
		sessionStorage.setItem('to','<?php echo $to ?>');
		sessionStorage.setItem('dep','<?php echo $dep ?>');
		sessionStorage.setItem('ret','<?php echo $ret ?>');
		
		sessionStorage.setItem('s_dep','<?php echo($s_dep)?>');
		sessionStorage.setItem('s_dur','<?php echo($s_dur)?>');
		sessionStorage.setItem('s_prc','<?php echo($s_prc)?>');
		
		sessionStorage.setItem('j_dep','<?php echo($j_dep)?>');
		sessionStorage.setItem('j_dur','<?php echo($j_dur)?>');
		sessionStorage.setItem('j_prc','<?php echo($j_prc)?>');
		
		sessionStorage.setItem('sg_dep','<?php echo($sg_dep)?>');
		sessionStorage.setItem('sg_dur','<?php echo($sg_dur)?>');
		sessionStorage.setItem('sg_prc','<?php echo($sg_prc)?>');
		
		sessionStorage.setItem('u_dep','<?php echo($u_dep)?>');
		sessionStorage.setItem('u_dur','<?php echo($u_dur)?>');
		sessionStorage.setItem('u_prc','<?php echo($u_prc)?>');

		location.href="./m.php"

	</script>

</body>
</html>
<?php
$conn=mysqli_connect('localhost','root','','contact');
/*$sql="CREATE TABLE cu(
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(30) NOT NULL,
email VARCHAR(50) NOT NULL,
message Varchar(50) NOT NULL
)";
$a=mysqli_query($conn,$sql);
mysqli_close($conn);
*/
$sql='INSERT INTO cu(name,email,message)VALUES("$_POST["name"]","$_POST["email"]","$_POST["message"]")';
mysqli_query($conn,$sql);


?>



<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<script type="text/javascript">
		alert("your details successfully stored");
		location.href="/flight/op12.php";
	</script>

</body>
</html>
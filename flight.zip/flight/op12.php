
<!DOCTYPE html>
<html>
<head>
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.5.0/css/all.css' integrity='sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU' crossorigin='anonymous'>
<link href="https://fonts.googleapis.com/css?family=Slabo+27px" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="./op12.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body id="ma2">
<img src="./Dark-Background-Wallpaper.jpg" class="main1">
<div class="main" id="ma22">
<div class="navbar" id="ma1">
  <a class="active" href="#"><i class="fa fa-fw fa-home"></i> Home</a> 
 
  <a href="./ContactFrom_v2/ContactFrom_v2/contact.html"><i class="fa fa-fw fa-envelope"></i> Contact</a> 
  <a href="/flight/login1.php" class="vis1" id="vis1" style="margin-left: 831px;visibility: visible;"><i class="fa fa-fw fa-user"></i> Login</a>

  <a href="#" class="vis2" id="vis2" style="margin-left: -4cm;visibility: hidden; position: absolute;">User </a>
  <a href="/flight/login1.php" class="vis2" id="vis2" style="margin-left: -2cm;visibility: hidden; position: absolute;">Logout</a>

</div>
</div>
<div class="choose">
  <span class="text">Hello <span id="change">there</span>
</span> 
  <span class="next"> welcome to Travel trolly flight booking site...</span>
    <span class="next1">get best flights with low cost</span>
  <a href="/flight/index.php"><span class="i2"><i class='fas fa-plane' style='font-size:200px;'></i></span></a>


</div>



<script type="text/javascript">
  var name=sessionStorage.getItem('usr');
  
    if(name!='123'){
    document.getElementById('change').innerHTML=name;

  
  var v1=document.getElementById('vis1');
  var v2=document.getElementById('vis2');

    v1.style.visibility="hidden";
    v2.style.visibility="visible";
    v2.innerHTML="<i class='far fa-user-circle' style='font-size:24px'></i>"+" user "+name +"<a href='/flight/login1.php/' style='margin-left:1cm;position:absolute;margin-top:-7px;'>logout</a>  ";
  }
</script>

</body>
</html> 
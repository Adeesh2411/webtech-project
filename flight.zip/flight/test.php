<?php
	$conn=mysqli_connect('localhost','root','',"Cambodia");
	//spice_jet
	$sql="SELECT departure,duration,price FROM data1 WHERE place='India'";
	$result=mysqli_query($conn,$sql);
	echo "A";
	if(mysqli_num_rows($result)>0)
	{
		while($row=mysqli_fetch_assoc($result))
		{
			echo "Adeesh";

			$s_dep=$row['departure'];
			$s_dur=$row['duration'];
			$s_prc=$row['price'];
			echo "$s_dep";
		}
	}
	/*   alert(num)
            //sessionStorage.setItem('no',length(realvalues));
             //location.href ="http://localhost:8080/mymovie/SeatBook.action?cseatsWanted="+realvalues;
                     
           
             //window.history.pushState({push:this.push},'','?booking='+realvalues)
	*/?>
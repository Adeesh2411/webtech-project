<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./m.css">
	<title></title>
<script type="text/javascript">
			function log(a){
			sessionStorage.setItem('cost',sessionStorage.getItem(a));
			location.href="./l1.html";

		}

</script>
</head>
<body>
	

		<div class="one">
			<img src="./topvoucher-logo (1).png" style="position: absolute;width: 5%;z-index: 1; margin-top: 4cm;left: 2cm;">
			<span style="position: absolute; left: 5cm;color: white ">to</span>
			<span style="position: absolute; left: 12cm;color: white">from</span>

			<span style="position: absolute;left: 21.5cm;color: white">depart</span>
			<span style="position: absolute;left: 27.5cm;color: white">return</span>
			<div class="from">
				<span id="from1" style="size:2em; position: absolute;margin: 10px;" id="from">from</span>
			</div>
				<div class="to">
					<p id="to1" style="margin:10px;">ads</p>
					
				</div>
					<div class="d-date">
						<p id="d-date" style="position: absolute;margin: 10px;text-align: center;">1date</p>
					</div>
						<div class="f-date">
							<span id="f-date" style="position: absolute;margin: 10px;">date</span>
						</div>
		<div class="two">
			<span style="display: inline;float: left;margin-left: 3cm;margin-top: 10px; ">Airlines</span>
			<span style="display: inline;float: left; margin-left: 4cm;margin-top: 10px;">Departure</span>
			<span style="display: inline;float: left; margin-left: 4cm;margin-top: 10px;">Duration</span>
			<span style="display: inline;float: left; margin-left: 4cm;margin-top: 10px;">Arrival</span>
			<span style="display: inline;float: left; margin-left: 4cm;margin-top: 10px;">price</span>
		</div>



		<span style="color: orange;margin-left: 4cm;margin-top:4.5cm;position: absolute;font-weight: bold;font-size: 2em; ">All Flights...</span>
		<div class="three">

		<div class="three1" style="margin-top: 6cm;margin-left: 3cm;">
			<img src="./c0e9134cea71190d29f1e0955b678feb.png" style="height: 50%;position: absolute;margin-top: 0.5cm">
			<span id="spice_dep" style="position: absolute;margin-left: 5.5cm;margin-top: 1cm;font-size: 1.5em;">16:15 php</span>
			<span id="spice_dur" style="position: absolute;margin-left: 10.5cm;margin-top: 1cm;font-size: 1.5em;">1:05</span>
			<span id="spice_arr" style="position: absolute;margin-left: 15.5cm;margin-top: 1cm;font-size: 1.5em;">17:15</span>
			<span id="spice_prc" style="position: absolute;margin-left: 20.5cm;margin-top: 1cm;font-size: 1.5em;">Rs 4500</span>
				<button onclick="log('s_prc')" style="background-color: #DC7633  ;margin-left: 23.5cm;width: 3cm;font-size: 1.5em;position: absolute;color: white;margin-top: 1cm;border-radius: 5px;">book</button>
			</div>


			<div class="three2">
				<img src="./images_1.jpeg" style="height: 50%;position: absolute;margin-top: 0.5cm;margin-left: 0.5cm">
			<span id="uia_dep" style="position: absolute;margin-left: 5.5cm;margin-top: 1cm;font-size: 1.5em;">20:15 php</span>
			<span id="uia_dur" style="position: absolute;margin-left: 10.5cm;margin-top: 1cm;font-size: 1.5em;">4:00</span>
			<span id="uia_arr" style="position: absolute;margin-left: 15.5cm;margin-top: 1cm;font-size: 1.5em;">0:15</span>
			<span id="uia_prc" style="position: absolute;margin-left: 20.5cm;margin-top: 1cm;font-size: 1.5em;">Rs 5000</span>
				<button onclick="log('u_prc')" style="background-color: #DC7633  ;margin-left: 23.5cm;width: 3cm;font-size: 1.5em;position: absolute;color: white;margin-top: 1cm;border-radius: 5px;">book</button>
		</div>




				<div class="three3">
					<img src="./singapore-airlines-logo.gif" style="height: 50%;position: absolute;">
			<span id="sg_dep" style="position: absolute;margin-left: 5.5cm;margin-top: 1cm;font-size: 1.5em;">1:00 php</span>
			<span id="sg_dur" style="position: absolute;margin-left: 10.5cm;margin-top: 1cm;font-size: 1.5em;">1:05</span>
			<span id="sg_arr" style="position: absolute;margin-left: 15.5cm;margin-top: 1cm;font-size: 1.5em;">18:15</span>
			<span id="sg_prc" style="position: absolute;margin-left: 20.5cm;margin-top: 1cm;font-size: 1.5em;">Rs 7000</span>
				<button onclick="log('sg_prc')" style="background-color: #DC7633  ;margin-left: 23.5cm;width: 3cm;font-size: 1.5em;position: absolute;color: white;margin-top: 1cm;border-radius: 5px;">book</button>
				</div>


					<div class="three4">
						<img src="./Jet_Airways_tcm638-1083202.png" style="height: 70%;position: absolute;">
			<span id="j_dep" style="position: absolute;margin-left: 5.5cm;margin-top: 1cm;font-size: 1.5em;">4:10 php</span>
			<span id="j_dur" style="position: absolute;margin-left: 10.5cm;margin-top: 1cm;font-size: 1.5em;">1:05</span>
			<span id="j_arr" style="position: absolute;margin-left: 15.5cm;margin-top: 1cm;font-size: 1.5em;">5:15</span>
			<span id="j_prc" style="position: absolute;margin-left: 20.5cm;margin-top: 1cm;font-size: 1.5em;">Rs 3788</span>
			<button onclick="log('j_prc')" style="background-color: #DC7633  ;margin-left: 23.5cm;width: 3cm;font-size: 1.5em;position: absolute;color: white;margin-top: 1cm;border-radius: 5px;">book</button>
					
			
						</div>


		
			
			<div class="ll">
		<div >
			<img src="./traveltrolley.jpg" class="side">
		</div>
		<div>
			<img src="./image_thumb36.png" class="side1">
		</div>
		<div>
			<img src="./transport-2292028_1920.jpg" class="side2">
		</div>
		<div class="foo">
		<span class="fl1">Follow Us on..</span>
		<div class="soc">
			<a href="#" class="fa fa-facebook"></a>
			<a href="#" class="fa fa-twitter"></a>
			<a href="#" class="fa fa-google"></a>
			<a href="#" class="fa fa-youtube"></a>
		</div>
		<span class="fl2">
			Travel trolly is Worlds largest online flight ticket bookingservice trusted by over 10 million happy customer globally 
		</span>
	</div>	
	</div>

		
	
	<script type="text/javascript">
	
		var fplace=sessionStorage.getItem('from');
		var to=sessionStorage.getItem('to');
		var fd=sessionStorage.getItem('dep');
		var ret=sessionStorage.getItem('ret');
		document.getElementById('to1').innerHTML=to;
		document.getElementById('from1').innerHTML=fplace;
		document.getElementById('d-date').innerHTML=fd;
		document.getElementById('f-date').innerHTML=ret;

		var s_dep = sessionStorage.getItem('s_dep');
		var s_dur = sessionStorage.getItem('s_dur');
		var s_prc = sessionStorage.getItem('s_prc');

		var j_dep = sessionStorage.getItem('j_dep'); 
		var j_dur = sessionStorage.getItem('j_dur');
		var j_prc = sessionStorage.getItem('j_prc');

		var sg_dep = sessionStorage.getItem('sg_dep');
		var sg_dur = sessionStorage.getItem('sg_dur');
		var sg_prc = sessionStorage.getItem('sg_prc');

		var u_dep = sessionStorage.getItem('u_dep');
		var u_dur = sessionStorage.getItem('u_dur');
		var u_prc = sessionStorage.getItem('u_prc');
		document.getElementById('spice_dep').innerHTML=s_dep+':00';
		document.getElementById('spice_dur').innerHTML=s_dur+':00';
		document.getElementById('spice_arr').innerHTML=parseInt(s_dur)+parseInt(s_dep)+':00';
		document.getElementById('spice_prc').innerHTML='Rs'+s_prc;


		document.getElementById('uia_dep').innerHTML=u_dep+':00';
		document.getElementById('uia_dur').innerHTML=u_dur+':00';
		document.getElementById('uia_arr').innerHTML=parseInt(u_dur)+parseInt(u_dep)+':00';
		document.getElementById('uia_prc').innerHTML='Rs'+u_prc;

		document.getElementById('sg_dep').innerHTML=sg_dep+':00';
		document.getElementById('sg_dur').innerHTML=sg_dur+':00';
		document.getElementById('sg_arr').innerHTML=parseInt(sg_dur)+parseInt(sg_dep)+':00';
		document.getElementById('sg_prc').innerHTML='Rs'+sg_prc;


		document.getElementById('j_dep').innerHTML=j_dep+':00';
		document.getElementById('j_dur').innerHTML=j_dur+':00';
		document.getElementById('j_arr').innerHTML=parseInt(j_dur)+parseInt(j_dep)+':00';
		document.getElementById('j_prc').innerHTML='Rs'+j_prc;
	


	</script>
</body>
</html>
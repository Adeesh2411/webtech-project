<?php
	$usr=$_POST['username'];
	$pass=$_POST['pass'];
	$p1="none";
	$conn=mysqli_connect('localhost','root','','table1');
	$sql="SELECT pass FROM tab1 WHERE username='$usr'";
	$result=mysqli_query($conn,$sql);
	if(mysqli_num_rows($result)>0)
	{
		while($row=mysqli_fetch_assoc($result)){
			$p1=$row['pass'];
			if($p1==$pass){
			$next="/flight/op12.php";
		}
		else{
			$next="/flight/login1.php";
		}
	}
	}
	else
	{
		$next="/flight/login1.php";
	}




?>
<script type="text/javascript">
	if("<?php echo $next?>"=="/flight/login1.php")
		alert("incorrect entry");
	else{
		alert("hurrahy")
	}
	location.href="<?php echo $next?>";
</script>
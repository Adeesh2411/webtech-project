<?php 
/*$conn=mysqli_connect('localhost','root','','table1');
$sql = "CREATE TABLE tab1 (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
username VARCHAR(30) NOT NULL,
pass VARCHAR(30) NOT NULL,
reg_date TIMESTAMP
)";
$a=mysqli_query($conn,$sql);
mysqli_close($conn);
?>

<?php
	$conn=mysqli_connect('localhost','root','','table1');
	$sql="INSERT INTO tab1(username,pass)VALUES('aa','aa')";
	mysqli_query($conn,$sql);

?>*/


$conn=mysqli_connect('localhost','root','','table1');
$sql="SELECT username FROM tab1";
$result=mysqli_query($conn,$sql);
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo  " - Name: " . $row["username"]. "<br>";
    }
} else {
    echo "0 results";
}

?>
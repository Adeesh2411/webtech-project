<?php
/*$conn=mysqli_connect('localhost','root','','userdata');
$sql="CREATE TABLE user(
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
email VARCHAR(50) NOT NULL,
address Varchar(50) NOT NULL,
city VARCHAR(30) NOT NULL,
state VARCHAR(30) NOT NULL,
zip VARCHAR(10) NOT NULL,
namec VARCHAR(30) NOT NULL,
cardnumber VARCHAR(30) NOT NULL,
month VARCHAR(5) NOT NULL,
year VARCHAR(5) NOT NULL,
cvv VARCHAR(3) NOT NULL
)";
$a=mysqli_query($conn,$sql);
mysqli_close($conn);
*/?>


<?php
	$conn=mysqli_connect('localhost','root','','userdata');
	$sql='INSERT INTO user(firstname,email,address,city,state,zip,namec,cardnumber,month,year,cvv) VALUES("$_POST["firstname"]","$_POST["email"]","$_POST["address"]","$_POST["city"]","$_POST["state"]","$_POST["zip"]","$_POST["cardname"]","$_POST["expmonth"]","$_POST["expyear"]","$_POST["cvv"]")';
	$a=mysqli_query($conn,$sql);
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<script type="text/javascript">
		alert("successfull");
		location.href="/flight/index.php";
	</script>

</body>
</html>
<?php
 
$conn=mysqli_connect('localhost','root','','table1');
$sql = "CREATE TABLE tab1 (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
username VARCHAR(30) NOT NULL,
pass VARCHAR(30) NOT NULL,
reg_date TIMESTAMP
)";
$a=mysqli_query($conn,$sql);
mysqli_close($conn);
?>

<?php
	$usr=$_POST['username'];
	$p=$_POST['pass'];
	$conn=mysqli_connect('localhost','root','','table1');
	$sql="INSERT INTO tab1(username,pass)VALUES('$usr','$p')";
	mysqli_query($conn,$sql);

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post"></form>
<script>
	location.href='/flight/op12.php';
</script>	
</form>
</body>
</html>